"""
MNIST opdracht C: "Only Conv"      (by Marius Versteegen, 2021)

Bij deze opdracht gebruik je geen dense layer meer.
De output is nu niet meer een vector van 10, maar een
plaatje van 1 pixel groot en 10 lagen diep.

Deze opdracht bestaat uit vier delen: C1 tm C4 (zie verderop)
"""
import numpy as np
from tensorflow import keras
from tensorflow.keras import layers
import matplotlib.pyplot as plt
from matplotlib import pyplot
import matplotlib
import random
from MavTools_NN import ViewTools_NN

# Model / data parameters
num_classes = 10

# the data, split between train and test sets
(x_train, y_train), (x_test, y_test) = keras.datasets.mnist.load_data()

# Scale images to the [0, 1] range
x_train = x_train.astype("float32") / 255
x_test = x_test.astype("float32") / 255

print(x_test[0])

print("show image\n")
plt.figure()
plt.imshow(x_test[0])
plt.colorbar()
plt.grid(False)
plt.show()

# Conv layers expect images.
# Make sure the images have shape (28, 28, 1). 
# (for RGB images, the last parameter would have been 3)
x_train = np.expand_dims(x_train, -1)
x_test = np.expand_dims(x_test, -1)

print("x_train shape:", x_train.shape)
print(x_train.shape[0], "train samples")
print(x_test.shape[0], "test samples")

# convert class vectors to binary class matrices
y_train = keras.utils.to_categorical(y_train, num_classes)
y_test = keras.utils.to_categorical(y_test, num_classes)

# change shape 60000,10 into 60000,1,1,10  which is 10 layers of 1x1 pix images, which I use for categorical classification.
y_train = np.expand_dims(np.expand_dims(y_train,-2),-2)
y_test = np.expand_dims(np.expand_dims(y_test,-2),-2)

"""
Opdracht C1: 
    
Voeg ALLEEN Convolution en/of MaxPooling2D layers toe aan het onderstaande model.
(dus GEEN dense layers, ook niet voor de output layer)
Probeer een zo eenvoudig mogelijk model te vinden (dus met zo min mogelijk parameters)
dat een test accurracy oplevert van tenminste 0.98.

Voorbeelden van layers:
    layers.Conv2D(getal, kernel_size=(getal, getal))
    layers.MaxPooling2D(pool_size=(getal, getal))

Beschrijf daarbij met welke stappen je bent gekomen tot je model,
en beargumenteer elk van je stappen.


Stap 1: Initiële Configuratie

Voor de eerste Conv2D-layer heb ik gekozen voor 32 filters in plaats van 16 om de representatiekracht van de eerste layer te vergroten. 
Deze keuze is gebaseerd op het idee dat de beginlayer eenvoudige kenmerken moet leren. 
Een layer met 32 filters kan effectiever basiskarakteristieken van de inputgegevens vastleggen.

Stap 2: Pooling en Diepere layers

Het toepassen van MaxPooling2D na elke Conv2D-layer helpt bij het verminderen van de ruimtelijke dimensies en het versterken van belangrijke kenmerken. 
De keuze voor 64 filters in de tweede Conv2D-layer is gebaseerd op het vergroten van de complexiteit van de geleerde kenmerken naarmate het netwerk dieper gaat. 
Hierdoor kan het model abstractere patronen herkennen.

Stap 3: Diepere lagen toevoegen

Het toevoegen van een derde Conv2D-layer met 128 filters vergroot de representatiekracht van het model verder. 
Hierdoor kan het model nog complexere kenmerken leren en beter generaliseren naar verschillende inputgegevens.

Stap 4: Output Layer

De laatste Conv2D-layer met 10 filters zorgt voor de gewenste uitvoer van een 1x1 afbeelding met 10 lagen, 
die elk overeenkomen met een cijfer van 0 tot 9. De keuze voor 10 filters komt overeen met het aantal klassen (cijfers) dat we willen classificeren, 
zoals beschreven staat in de opdracht.

De accurracy van het model is nu > 0.98, wat voldoet aan de vereiste nauwkeurigheid. 

BELANGRIJK (ivm opdracht D, hierna):  
* Zorg er dit keer voor dat de output van je laatste layer bestaat uit een 1x1 image met 10 lagen.
Met andere woorden: zorg ervoor dat de output shape van de laatste layer gelijk is aan (1,1,10)
De eerste laag moet 1 worden bij het cijfer 0, de tweede bij het cijfer 1, etc.

Tip: Het zou kunnen dat je resultaat bij opdracht B al aardig kunt hergebruiken,
     als je flatten en dense door een conv2D vervangt.
     Om precies op 1x1 output uit te komen kun je puzzelen met de padding, 
     de conv kernal size en de pooling.
     
* backup eventueel na de finale succesvolle training van je model de gegenereerde weights file
  (myWeights.m5). Die kun je dan in opdracht D inladen voor snellere training.
  
  
Spoiler-mogelijkheid:
Mocht het je te veel tijd kosten (laten we zeggen meer dan een uur), dan
mag je de configuratie uit Spoiler_C.py gebruiken/kopieren.

Probeer in dat geval te beargumenteren waarom die configuratie een goede keuze is.
"""

def buildMyModel(inputShape):
    model = keras.Sequential([
        keras.Input(shape=inputShape),
        layers.Conv2D(32, kernel_size=(3, 3), activation="relu"),
        layers.MaxPooling2D(pool_size=(2, 2)),
        layers.Conv2D(64, kernel_size=(3, 3), activation="relu"),
        layers.MaxPooling2D(pool_size=(2, 2)),
        layers.Conv2D(128, kernel_size=(3, 3), activation="relu"),
        layers.MaxPooling2D(pool_size=(2, 2)),
        layers.Conv2D(10, kernel_size=(1, 1), activation="softmax")
    ])
    return model

model = buildMyModel(x_train[0].shape)
model.summary()

"""
Opdracht C2: 
    
Kopieer bovenstaande model summary en verklaar bij 
bovenstaande model summary bij elke laag met kleine berekeningen 
de Output Shape

- Conv2D: 
  De eerste Conv2D-laag heeft 32 filters met een kernel size van (3, 3). 
  Omdat er geen padding is toegepast, en de inputafmetingen (28, 28, 1) zijn, wordt de output shape (None, 26, 26, 32). 
  Dit betekent dat er 32 feature maps zijn van grootte 26x26.
  Berekeningen: (28 - 3 + 2 * 0) / 1 + 1 = 26

- MaxPooling2D: 
  MaxPooling met een pool size van (2, 2) wordt toegepast op de output van de eerste Conv2D-laag. 
  Hierdoor worden de ruimtelijke dimensies gehalveerd. De output shape wordt (None, 13, 13, 32).
  Berekeningen: 26 / 2 = 13

- Conv2D_1: 
  De tweede Conv2D-laag heeft 64 filters met een kernel size van (3, 3). 
  Omdat er geen padding is toegepast, blijft de output shape (None, 11, 11, 64). 
  Er zijn nu 64 feature maps van grootte 11x11.
  Berekeningen: (13 - 3 + 2 * 0) / 1 + 1 = 11

- MaxPooling2D_1: 
  MaxPooling met een pool size van (2, 2) wordt toegepast op de output van de tweede Conv2D-laag. 
  Hierdoor worden de ruimtelijke dimensies opnieuw gehalveerd. De output shape wordt (None, 5, 5, 64).
  Berekeningen: 11 / 2 = 5

- Conv2D_2: 
  De derde Conv2D-laag heeft 128 filters met een kernel size van (3, 3). 
  Omdat er geen padding is toegepast, blijft de output shape (None, 3, 3, 128). 
  Er zijn nu 128 feature maps van grootte 3x3.
  Berekeningen: (5 - 3 + 2 * 0) / 1 + 1 = 3

- MaxPooling2D_2: 
  MaxPooling met een pool size van (2, 2) wordt toegepast op de output van de derde Conv2D-laag. 
  Hierdoor worden de ruimtelijke dimensies opnieuw gehalveerd. De output shape wordt (None, 1, 1, 128).
  Berekeningen: 3 / 2 = 1

- Conv2D_3: 
  De laatste Conv2D-laag heeft 10 filters met een kernel size van (1, 1). 
  Omdat er geen padding is toegepast, blijft de output shape (None, 1, 1, 10). 
  Dit komt overeen met de gewenste uitvoer van een 1x1 afbeelding met 10 lagen, 
  die elk overeenkomen met een cijfer van 0 tot 9.
  Berekeningen: (1 - 1 + 2 * 0) / 1 + 1 = 1

"""

"""
Opdracht C3: 
    
Verklaar nu bij elke laag met kleine berekeningen het aantal parameters.

  Parameters = (Kernel Size * Input Channels + 1) * Number of Filters
  Voor de eerste Conv2D-laag: (3 * 3 * 1 + 1) * 32 = 320 parameters
  Voor de tweede Conv2D-laag: (3 * 3 * 32 + 1) * 64 = 18496 parameters
  Voor de derde Conv2D-laag: (3 * 3 * 64 + 1) * 128 = 73856 parameters
  Voor de laatste Conv2D-laag: (1 * 1 * 128 + 1) * 10 = 1290 parameters

Totaal aantal parameters = 320 + 18496 + 73856 + 1290 = 93622
de maxpooling layers hebben geen parameters.


"""

"""
Opdracht C4: 
    
Bij elke conv layer hoort een aantal elementaire operaties (+ en *).
* Geef PER CONV LAYER een berekening van het totaal aantal operaties 
  dat nodig is voor het klassificeren van 1 test-sample.
* Op welk aantal operaties kom je uit voor alle conv layers samen?

 Conv2D:
  Voor elke pixel in de output:
  - Een vermenigvuldiging per gewicht (kernel size * input channels)
  - Een optelling per gewicht
  Dit gebeurt voor elk filter.

Totaal aantal operaties voor één Conv2D-laag:
  Operaties per filter = (Kernel Size * Input Channels) + 1 (voor de bias)
  Totaal operaties = Operaties per filter * Aantal Filters

Voor de eerste Conv2D-laag: (26 * 26 * 32 + 1) * 32 = 216,985 operaties
Voor de tweede Conv2D-laag: (11 * 11 * 64 + 1) * 64 = 50,689 operaties
Voor de derde Conv2D-laag: (3 * 3 * 128 + 1) * 128 = 147,584 operaties
Voor de laatste Conv2D-laag: (1 * 1 * 10 + 1) * 10 = 110 operaties

Totaal aantal operaties voor alle Conv2D-lagen = 216,985 + 50,689 + 147,584 + 110 = 415,368 operaties


"""

"""
## Train the model
"""

batch_size = 8000 # Larger means faster training, but requires more system memory.
epochs = 250 # for now

bInitialiseWeightsFromFile = False # Set this to false if you've changed your model.

learningrate = 0.0001 if bInitialiseWeightsFromFile else 0.01

# We gebruiken alvast mean_squared_error ipv categorical_crossentropy als loss method,
# omdat straks bij opdracht D ook de afwezigheid van een cijfer een valide mogelijkheid is.
optimizer = keras.optimizers.Adam(lr=learningrate) #lr=0.01 is king
model.compile(loss='mean_squared_error',
              optimizer=optimizer,
              metrics=['categorical_accuracy'])

print("x_train.shape")
print(x_train.shape)

print("y_train.shape")
print(y_train.shape)

if (bInitialiseWeightsFromFile):
    model.load_weights("myWeights.h5"); # let's continue from where we ended the previous time. That should be possible if we did not change the model.
                                        # if you use the model from the spoiler, you
                                        # can avoid training-time by using "Spoiler_C_weights.h5" here.
try:
    model.fit(x_train, y_train, batch_size=batch_size, epochs=epochs, validation_split=0.2)
except KeyboardInterrupt:
    print("interrupted fit by keyboard")

"""
## Evaluate the trained model
"""

score = model.evaluate(x_test, y_test, verbose=0)
print("Test loss:", score[0])
print("Test accuracy:", ViewTools_NN.getColoredText(255,255,0,score[1]))

model.summary()

model.save_weights('myWeights.h5')

prediction = model.predict(x_test)
print(prediction[0])
print(y_test[0])

# summarize feature map shapes
for i in range(len(model.layers)):
	layer = model.layers[i]
	# check for convolutional layer
	if 'conv' not in layer.name:
		continue
	# summarize output shape
	print(i, layer.name, layer.output.shape)


print(x_test.shape)

# study the meaning of the filtered outputs by comparing them for
# multiple samples
nLastLayer = len(model.layers)-1
nLayer=nLastLayer
print("lastLayer:",nLastLayer)

baseFilenameForSave=None
x_test_flat=None
ViewTools_NN.printFeatureMapsForLayer(nLayer, model, x_test_flat, x_test, 0, baseFilenameForSave)
ViewTools_NN.printFeatureMapsForLayer(nLayer, model, x_test_flat, x_test, 1, baseFilenameForSave)
ViewTools_NN.printFeatureMapsForLayer(nLayer, model, x_test_flat, x_test, 2, baseFilenameForSave)
ViewTools_NN.printFeatureMapsForLayer(nLayer, model, x_test_flat, x_test, 3, baseFilenameForSave)
ViewTools_NN.printFeatureMapsForLayer(nLayer, model, x_test_flat, x_test, 4, baseFilenameForSave)
ViewTools_NN.printFeatureMapsForLayer(nLayer, model, x_test_flat, x_test, 6, baseFilenameForSave)
ViewTools_NN.printFeatureMapsForLayer(nLayer, model, x_test_flat, x_test, 5, baseFilenameForSave)
ViewTools_NN.printFeatureMapsForLayer(nLayer, model, x_test_flat, x_test, 7, baseFilenameForSave)
